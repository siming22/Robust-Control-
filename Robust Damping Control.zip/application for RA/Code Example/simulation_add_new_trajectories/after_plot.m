%�ο��˶����
xr_value = xr.Data;
yr_value = yr.Data;
theta_r_value = theta_r.Data;
vr_value = vr.Data;
omega_r_value = omega_r.Data;
time = xr.Time;
%��ʵ�˶����
x_value = q.Data(:,1);
y_value = q.Data(:,2);
theta_value = q.Data(:,3);
v1_value = V.Data(:,1);
v2_value = V.Data(:,2);
%�������
erro_x = x_value - xr_value;
erro_y = y_value - yr_value;
erro_theta = theta_value - theta_r_value;
for i = 1:length(erro_theta)
    if erro_theta(i) > pi
        erro_theta(i) = 2*pi - erro_theta(i);
    elseif erro_theta(i) < -pi
        erro_theta(i) = -(2*pi + erro_theta(i));
    end
end
erro_v1 = v1_value - vr_value;
erro_v2 = v2_value - omega_r_value;
%������ͼ
motion_flag = 2;
figure(1)
plot(time,erro_x)
hold on
plot(time,erro_y)
plot(time,erro_theta)
hold off
xlabel('Time(s)');ylabel('Position Erros(DE)');
legend('X','Y','Theta')
if motion_flag ~= 3
    ylim([-0.5 0.5])
end

figure(2)
plot(time,erro_v1)
hold on
plot(time,erro_v2)
hold off
xlabel('Time(s)');ylabel('Velocity Erros(m/s)');
legend('Linear velocity','Angular Velocity')
if motion_flag ~= 3
    ylim([-1 1])
end


tao_x = tao.Data(:,1);
tao_y = tao.Data(:,2);
figure(3)
plot(time,tao_y)
if motion_flag ~= 3
    ylim([-5 5])
end
xlabel('Time(s)');ylabel('Left Torque(N*m)');

figure(4)
plot(time,tao_x)
if motion_flag ~= 3
    ylim([-5 5])
end
xlabel('Time(s)');ylabel('Right Torque(N*m)');

figure(5)
plot(xr_value,yr_value,'o')
hold on
plot(x_value,y_value)
hold off
xlabel('X');ylabel('Y')
legend('Reference Trajectory','Real Trajectory')
switch motion_flag
    case 1
        xlim([-3 3])
        ylim([0 5])
    case 2
        xlim([-1 15])
        ylim([-2 3])
    case 3
        xlim([-1 3])
        ylim([-1 3])
    otherwise
        disp('wrong value: motion_flag')
end